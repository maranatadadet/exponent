#!/bin/sh
source "/anaconda3"/bin/activate root
"/anaconda3"/bin/anaconda-navigator $@
